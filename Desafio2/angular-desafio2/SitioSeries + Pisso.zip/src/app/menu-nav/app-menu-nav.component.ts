import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-menu-nav',
  templateUrl: './app-menu-nav.component.html',
  styleUrls: ['./app-menu-nav.component.scss']
})
export class AppMenuNavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
