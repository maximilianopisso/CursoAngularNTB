import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-peliculas-section',
  templateUrl: './peliculas-section.component.html',
  styleUrls: ['./peliculas-section.component.scss']
})
export class PeliculasSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
